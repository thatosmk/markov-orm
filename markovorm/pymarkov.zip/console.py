from python_markov import PyMarkov
from sql_python import SQLPy

def connect():
    """ call SQLPy with credentials to connect """
    from setup import *
    
    con = SQLPy(user, password, server, database, driver)

    return con

def startup():
    """ print the startup string """
    import os

    print "Welcome to PyMarkov"
    print ""

    # check if a file exists
    if os.path.isfile("setup.py") :
        # prompt for credentials
        return connect()
        print "Connected to the database"
    else:
        # go ahead connect to the database
        return get_cred()

def get_cred():
    """ gather credentials """
    import getpass 

    user = raw_input("username: ")
    password= getpass.getpass("password: ")
    database= raw_input("database_name: ")
    server= raw_input("host: ")
    driver= raw_input("linux/win - type(linux or win): ")
    # save credentials?
    save = raw_input("Store credentials?(Y/n): ")
    
    if (driver.lower() == "linux"):
        driver = "mysqldb"
    else: 
        driver = "pymysql"


    # prompt to ask to save credentials
    if (save.lower() == 'y'):
        # write to text file
        with open("setup.py", 'w') as f:
            f.write("user="+"\""+user+"\""+"\n")
            f.write("password="+"\""+password+"\""+"\n")
            f.write("server="+"\""+server+"\""+"\n")
            f.write("database="+"\""+database+"\""+"\n")
            f.write("driver="+"\""+driver+"\""+"\n")
            f.close()
    print "Credentials saved."
    # establish a connection
    con = SQLPy(user, password, server, database, driver)

    return con

def common_cmds():
    """ print common commands for user to get started """
    print "Type 'show transition matrix' to get the transition matrix"
    print "     'show data' to get the matrix before transition matrix" 
    #print "     'show absorbing' to get the absorbing matrix" 
    #print "     'show non-absorbing' to get the absorbing matrix" 

if __name__ == "__main__":

    db = startup()
    # grab the table data
    print "Enter your query: "
    query = raw_input()
    
    data = db.get_table(query)

    # call PyMarkov
    markov = PyMarkov(data) 

    print "You can now start making you computations."

    print "Type these commmon commands"
    # print common cmds
    common_cmds()

    # hard code the data_matrix
    matrix = markov.get_matrix_array()

    # begin the console prompt
    cmd = raw_input("pymarkov>")

    while(cmd.lower() != "quit"):
        if cmd == "show transition matrix": 
            print markov.get_trans_matrix()
        elif cmd == "show data": 
            print matrix
        elif cmd == "show absorbing": 
            print markov.get_abs_matrix(matrix)
        elif cmd == "show non-absorbing": 
            print markov.get_transient_matrix(matrix)
        elif cmd == "help": 
            common_cmds()
        else:
            print "Sorry unknown command"
            common_cmds()

        cmd = raw_input("pymarkov>")
        

""" connect credentials for SQLPy """
user = 'Ryan'
password = 'Ryan12345'
database = 'analytics_ryan'
server = 'analytics.technocore.co.za'
driver = 'mysqldb'
